%% Analog Filters
% Clear variables and Clear command window
clear
clc

% Polynomial Multiplication
p1 = [1 9 40];
p2 = [1 4];
Den = zeros(1, length(p1) + length(p2) - 1);

for i = 1 : length(p1)
    for j = 1 : length(p2)
        Den(i + j - 1) = Den(i + j - 1) + p1(i) * p2(j);
    end
end

% Transfer Function
Num = [25 100];
% Den = [ ... ];
G = tf(Num, Den);

%% Filter
% Parameters
w_B = 5;

% Order 2
w = 1.27;
zeta = 0.87;
[ G_f1 ] = analogfilter( w, zeta, w_B );

Num_f1 = cell2mat(G_f1.Numerator);
Den_f1 = cell2mat(G_f1.Denominator);

% Order 4
w = 1.60;
zeta = 0.62;
[ G_f21 ] = analogfilter( w, zeta, w_B );

w = 1.43;
zeta = 0.96;
[ G_f22 ] = analogfilter( w, zeta, w_B );

G_f2 = G_f21 * G_f22;

Num_f2 = cell2mat(G_f2.Numerator);
Den_f2 = cell2mat(G_f2.Denominator);

%% Simulation
A = 0.1;

%% Bode
% bode(G_f2)