function [ G ] = analogfilter( w, zeta, w_B )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
G = tf(w_B^2 * w^2, [1 (2 * zeta * w * w_B) (w_B^2 * w^2)]);

end

