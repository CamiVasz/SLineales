% Compare the nonlinear model with the linear model

% Inverted Pendulum

% Author: Sergio Andres Lenis Zapata
% Course: Linear Systems
% Date: Saturday, 18 November 2017

%% ===== Initialise =====
% Remove items from workspace, Remove specified figure and Clear Command Window
clear
close all
clc

% Linear model
linmod_trfunc

%
title_str = {'Title1', 'Title2'};
type_str = {'Posición del carro (m)', 'Ángulo del péndulo (rad)'};

%% ========== Comparison ==========
% Equilibrium point
x_pe = [0 0 0 0]';
u_pe = 0;

for i = 1 : 2
    for j = 1 : 2
        % Figure
        figure((i - 1) * 2 + j)
        
        % ========== Simulink ==========
        % Step input
        u_A = 0;
        
        % New initial conditions
        x_0 = 0;
        theta_0 = (pi / (i * 2));
        xdot_0 = 0;
        thetadot_0 = 0;
        x0 = [x_0 theta_0 xdot_0 thetadot_0]';
        
        % Simulation time
        t_f = 50;
        
        % Simulink
        simOut = sim('inverted_pendulum_comp', 'StopTime', num2str(t_f), ...
            'SaveTime', 'on', 'TimeSaveName', 't', ...
            'ReturnWorkspaceOutputs', 'on');
        t_sim = simOut.get('t')';
        nonlin_out = simOut.get('nonlin_out')';
        lin_out = simOut.get('lin_out')';
        
        % ========== Plot ==========
        %
        plot(t_sim, lin_out(j, :), t_sim, nonlin_out(j, :))
        title(cell2mat(title_str(i)))
        legend('Modelo lineal', 'Modelo no lineal')
        xlabel('Tiempo (s)')
        ylabel(cell2mat(type_str(j)))
        fname = ['comp' num2str(i) num2str(j) '.tex'];
        matlab2tikz(['../Fig/' fname], 'standalone', true)
    end
end