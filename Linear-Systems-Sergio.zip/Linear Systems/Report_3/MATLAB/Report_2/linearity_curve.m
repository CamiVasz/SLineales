% Linearity curve
% Inverted Pendulum

% Author: Sergio Andres Lenis Zapata
% Course: Linear Systems
% Date: Monday, 30 October 2017

%% ===== Initialise =====
% Remove items from workspace, Remove specified figure and Clear Command Window
clear
close all
clc

% Initialise variables
initvar

% Simulation time
t_f = 200;

% Step size
h2 = 1 / 10;

% Linearity curve
lin_c = [];
lin_c_2 = [];

%% ===== Linearity curve =====
% Input
for u = -5 : 0.1 : 5
    for lin = 1 : 2
        % State equations
        if lin == 1
            % Linear model
            f_1 = @(x) x(3);
            f_2 = @(x) x(4);
            f_3 = @(x) ((inertia + mp * len^2) * ...
                (u - b * x(3)) + mp^2 * g * len^2 * x(2)) / ...
                (inertia * (mc + mp) + mc * mp * len^2);
            f_4 = @(x) (- mp * len * (u - b * x(3)) - ...
                mp * g * len * (mc + mp) * x(2)) / ...
                (inertia * (mc + mp) + mc * mp * len^2);
        else
            % Nonlinear model
            f_1 = @(x) x(3);
            f_2 = @(x) x(4);
            f_3 = @(x) ((inertia + mp * len^2) * ...
                (u - b * x(3) + mp * len * x(4)^2 * sin(x(2))) + ...
                mp^2 * g * len^2 * sin(x(2)) * cos(x(2))) / ...
                (inertia * (mc + mp) + mc * mp * len^2 + mp^2 * len^2 * sin(x(2))^2);
            f_4 = @(x) (- mp * len * (u - b * x(3) + mp * len * x(4)^2 * sin(x(2))) - ...
                mp * g * len * (mc + mp) * sin(x(2))) / ...
                (inertia * (mc + mp) + mc * mp * len^2 + mp^2 * len^2 * sin(x(2))^2);
        end
        
        % Runge–Kutta
        [ t_rk, x_rk ] = rungekutta( t_f, h2, x0, f_1, f_2, f_3, f_4 );

        if lin == 1
            lin_c = [lin_c, [u x_rk(2, end)]'];
        else
            lin_c_2 = [lin_c_2, [u x_rk(2, end)]'];
        end
    end
end

% Figure
figure
hold on

% Values
num = 1;
ymax = 0.02;

% Linearity curve
plot(lin_c(1, :), lin_c(2, :), lin_c_2(1, :), lin_c_2(2, :))
axis([-5 5 -ymax ymax])
plot([-num -num], [-ymax ymax], 'k--', [num num], [-ymax ymax], 'k--')

%
legend('Modelo lineal', ...
    'Modelo no lineal')
xlabel('Entrada (N)')
ylabel('Ángulo del péndulo (rad)')
% matlab2tikz('../IEEEtran/fig/linearity_c.tex', 'standalone', true)