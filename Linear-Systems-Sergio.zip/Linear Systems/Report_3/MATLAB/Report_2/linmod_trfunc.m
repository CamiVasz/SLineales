% Linear model
% Transfer function
% Routh-Hurwitz

% Inverted Pendulum

% Author: Sergio Andres Lenis Zapata
% Course: Linear Systems
% Date: Saturday, 18 November 2017

%% ===== Initialise =====
% Remove items from workspace, Remove specified figure and Clear Command Window
% clear
% close all
% clc

% Initialise variables
initvar

% Constants
c1 = mp^2  * g * len^2 / alpha;
c2 = ((inertia + mp * len^2) * b / alpha);
c3 = (mp * g * len * (mc + mp) / alpha);
c4 = (mp * len * b / alpha);
c5 = (inertia + mp * len^2) / alpha;
c6 = (mp * len / alpha);

%% ========== Linear model ==========
% ===== Analytically =====
% Matrices
A = [0 0 1 0;
    0 0 0 1;
    0 c1 -c2 0;
    0 -c3 c4 0];
B = [0 0 c5 -c6]';
C = [1 0 0 0; 0 1 0 0];
D = [0 0]';

% ===== MATLAB =====
% Linmod
[Am, Bm, Cm, Dm] = linmod('inverted_pendulum_linmod', [0, 0, 0, 0]);

%% ========== Transfer function ==========
% ===== Analytically
% Laplace s
s = tf('s');

% Transfer function
tf_1 = (c5 * s^2 - (c1 * c6 - c3 * c5)) / (s^4 + c2 * s^3 + c3 * s^2 + (c2 * c3 - c1 * c4) * s);
tf_2 = (-c6 * s + (c4 * c5 - c2 * c6)) / (s^3 + c2 * s^2 + c3 * s + (c2 * c3 - c1 * c4));

% ===== MATLAB
S = ss(Am, Bm, Cm, Dm);
G = tf(S);

%% ========== Routh-Hurwitz ==========
% New constants
c2_ = c2 / b;
c4_ = c4 / b;

% Parameter b - Coefficient of friction for cart (N/m/sec)
tf_1b = (c2_ * s^3 + (c2_ * c3 - c1 * c4_) * s) / (s^4 + c3 * s^2);
tf_2b = (c2_ * s^2 + (c2_ * c3 - c1 * c4_)) / (s^3 + c3 * s);

%% ========== Comparison ==========
% Equilibrium point
x_pe = [0 0 0 0];
u_pe = 0;

% Initial conditions
% x0 = [x_0 theta_0 xdot_0 thetadot_0]';