% Initialise Variables
% Inverted Pendulum

% Author: Sergio Andres Lenis Zapata
% Course: Linear Systems
% Date: Saturday, 18 November 2017

%% ===== Initialise Variables =====

% Define parameters
mc = 0.5;                           % Mass of the cart (kg)
mp = 0.2;                           % Mass of the pendulum (kg)
b = 0.1;                            % Coefficient of friction for cart (N/m/sec)
len = 0.3;                          % Length to pendulum center of mass (m)
inertia = (1 / 3) * mp * len^2;     % Mass moment of inertia of the pendulum (kg.m^2)
g = 9.80665;                        % Gravity (m/sec^2)

alpha = inertia * (mc + mp) + mc * mp * len^2;

% Initial conditions
x_0 = 0;
theta_0 = 0;
xdot_0 = 0;
thetadot_0 = 0;
x0 = [x_0 theta_0 xdot_0 thetadot_0]';

% Input parameters
ind = 1;                % Index _ Constant
u_amp = 0;