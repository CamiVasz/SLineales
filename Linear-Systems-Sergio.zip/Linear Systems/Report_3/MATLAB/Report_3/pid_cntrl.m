% PID - Heuristics

% Author: Sergio Andres Lenis Zapata
% Course: Linear Systems
% Date: Saturday, 18 November 2017

%% PID Data
% Clear variables and Clear command window
clear
close all
clc

% Transfer function
linmod_trfunc
G = tf_2;

% Parameters
Ts = 0.03;

% Continuous to Discrete
Gd = c2d(G, Ts);
Roots_Gd = roots(cell2mat(Gd.Denominator));

% Data for Transfer function
Num = cell2mat(Gd.Numerator);
Den = cell2mat(Gd.Denominator);

% Simulation
f_time = 1;
[ y, t ] = step(G, f_time);

% Reaction curve
t_1 = 0.1;
t_2 = 0.4;
pos = t(t < t_2) > t_1;
new_t = t(pos);
new_y = y(pos);

% Linear function
m = (new_y(end) - new_y(1)) / (new_t(end) - new_t(1));
f = @(x) m .* (x - new_t(1)) + new_y(1);

% Find L and R
Lm = 0;
while f(Lm) > 0
    Lm = Lm + 0.01;
end
L = Lm + Ts / 2;
R = m;

% Plot
sim_time = 0 : 0.11 : t_2;
plot(t, y, sim_time, f(sim_time), [0 f_time], [0 0], 'k--', [Lm Lm], [-1 1], 'k--')
title('Curva de reacción')
xlabel('Tiempo (s)')
ylabel('Ángulo del péndulo (rad)')
fname = 'pid_control_curve.tex';
% matlab2tikz(['../Fig/' fname], 'standalone', true)

%% Heuristics
% Close
close all

% Difficulty
S_0 = R * L;

% Ziegler-Nichols - Reaction Curve
ZN = [(1 / S_0) Inf 0; (0.9 / S_0) (3 * L) 0; (1.2 / S_0) (2 * L) (0.5 * L)];

% Chien-Hrones-Reswick
CHR0 = [(0.3 / S_0) Inf 0; (0.6 / S_0) (4 * L) 0; (0.95 / S_0) (2.4 * L) (0.42 * L)];
CHR20 = [(0.7 / S_0) Inf 0; (0.7 / S_0) (2.3 * L) 0; (1.2 / S_0) (2 * L) (0.42 * L)];

% Bode
% margin(c2d(G, Ts))

% Ziegler-Nichols - Sensitivity method
[ Gm, ~, Wcg, ~ ] = margin(c2d(G, Ts));
Ku = Gm;
Tu = 2 * pi / Wcg;

SM = [(0.5 * Ku) Inf 0; (0.45 * Ku) (Tu / 1.2) 0; (0.6 * Ku) (Tu / 2) (Tu / 8)];

title_str = {'P', 'PI', 'PID'};
for j = 1 : 2
    for i = 1 : 3
        % Figure
        figure((j - 1) * 3 + i)
        
        % Parameters
        if j == 1
            K = ZN(i, :);
        else
            K = SM(i, :);
        end
        
        Kp = K(1);
        Ti = K(2);
        Td = K(3);
        
        q_0 = Kp * (1 + Ts / (2 * Ti) + Td / Ts);
        q_1 = - Kp * (1 - Ts / (2 * Ti) + 2 * Td / Ts);
        q_2 = Kp * Td / Ts;
        
        % Data for Transfer function - Control
        Num_cd = [q_0 q_1 q_2];
        Den_cd = [1 -1 0];
        
        % Simulation
        % Simulation time
        t_f = [5 5 5 5 5 5];
        
        % Simulink
        simOut = sim('pid_control_model', 'StopTime', num2str(t_f((j - 1) * 3 + i)), ...
            'SaveTime', 'on', 'TimeSaveName', 't', ...
            'ReturnWorkspaceOutputs', 'on');
        t_sim = simOut.get('t')';
        theta = simOut.get('simout')';
        t_sim = decimate(t_sim, floor(length(t_sim) / length(theta)));
        t_sim = t_sim(1 : length(theta));
        
        % ========== Plot ==========        
        plot(t_sim, theta)
        init_name = {'Curva de reacción', 'Método de sensibilidad'};
        title([cell2mat(init_name(j)) ' (' cell2mat(title_str(i)) ')'])
        xlabel('Tiempo (s)')
        ylabel('Ángulo del péndulo (rad)')
        fname_init = {'zn', 'sm'};
        fname = ['pid_control_' cell2mat(fname_init(j)) '_' cell2mat(title_str(i)) '.tex'];
%         matlab2tikz(['../Fig/' fname], 'standalone', true)
    end
end

%
close all