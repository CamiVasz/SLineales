% Integral Control

% Author: Sergio Andres Lenis Zapata
% Course: Linear Systems
% Date: Saturday, 18 November 2017

%% Integral Control
% Clear variables and Clear command window
clear
close all
clc

% Transfer function
linmod_trfunc
G = tf_2;

% Numerator and Denominator
Num = cell2mat(G.Numerator);
Den = cell2mat(G.Denominator);

% Parameters
Ts = 0.03;

%
G_c = tf([-0.25 -2.5], [1 0 0]);
G_cd = c2d(G_c, Ts);

% Numerator and Denominator
Num_cd = cell2mat(G_cd.Numerator);
Den_cd = cell2mat(G_cd.Denominator);

% Initialise
analog_filters
sat = 4;

%% ========== Plot ==========
% % ===== Position
% figure
% plot(t_sim, x_sim, t_e, x_e(1, :), t_rk, x_rk(1, :))
% legend('Simulink', 'Método de Euler', 'Runge–Kutta')
% xlabel('Tiempo (s)')
% ylabel('Posición del carro (m)')
% matlab2tikz('../Fig/num_methods_pos.tex', 'standalone', true)

% ===== Angle
figure
plot(tout, simout(:, 2), tout, simout(:, 4))
legend('Comportamiento real', 'Referencia')
xlabel('Tiempo (s)')
ylabel('Ángulo del péndulo (rad)')
% matlab2tikz('../Fig/control_with_s.tex', 'standalone', true)

% ===== Control action
figure
plot(tout, simout(:, 3))
% legend('Acción de control')
xlabel('Tiempo (s)')
ylabel('Acción de control (N)')
axis([0 60 -5 0])
% matlab2tikz('../Fig/control_with_s_action.tex', 'standalone', true)