% PID - Pole

% Author: Sergio Andres Lenis Zapata
% Course: Linear Systems
% Date: Saturday, 18 November 2017

%% PID Data
% Clear variables and Clear command window
clear
close all
clc

% Transfer function
linmod_trfunc
G = tf_2;

% Parameters
Ts = 0.01;

% Continuous to Discrete
Gd = c2d(G, Ts);

% ===== Denominator =====
Roots_Gd = roots(cell2mat(Gd.Denominator));

%
num_1 = real(Roots_Gd(1));
num_2 = imag(Roots_Gd(1));
num_1 = -num_1;

%
p1 = [1 (2 * num_1) (num_1^2 + num_2^2)];
disp(p1)

% ===== Numerator =====
Num_disc = cell2mat(Gd.Numerator);
Roots_Gdn = roots(Num_disc)