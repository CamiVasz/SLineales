% State Feedback - Steady

% Author: Sergio Andres Lenis Zapata
% Course: Linear Systems
% Date: Sunday, 19 November 2017

%% State Feedback - Steady
% Clear variables and Clear command window
clear
clc

% Initialise
% initvar
analog_filters
discrete_model

%
New_A = [[S_d.A zeros(length(S_d.A), size(S_d.C, 1))]; [-S_d.C eye(size(S_d.C, 1))]];
New_B = [S_d.B' 0 0]';
New_C = [S_d.C zeros(size(S_d.c, 1))];
New_D = 0;

New_S = ss(New_A, New_B, New_C, New_D, Ts);

% Initial conditions
% x_0 = 10;
% theta_0 = pi / 4;

% Discrete S_d
%
% K = acker(New_S.A, New_S.B, [0.95 0.9 0.85 0.8 0.75 0.7]);
K = place(New_S.A, New_S.B, [0.95 0.9 0.85 0.8 0.75 0.7]);
% %% Plot
% t_f = 100;
% 
% simOut = sim('state_feedback_mod', 'StopTime', num2str(t_f), ...
%     'SaveTime', 'on', 'TimeSaveName', 't', ...
%     'ReturnWorkspaceOutputs', 'on');
% tout = simOut.get('t')';
% simout = simOut.get('simout')';
% 
% % ===== Position
% figure
% plot(tout, simout(1, :))
% xlabel('Tiempo (s)')
% ylabel('Posición del carro (m)')
% matlab2tikz('../Fig/state_feed_pos.tex', 'standalone', true)
% 
% % ===== Angle
% figure
% plot(tout, simout(2, :))
% xlabel('Tiempo (s)')
% ylabel('Ángulo del péndulo (rad)')
% matlab2tikz('../Fig/state_feed_ang.tex', 'standalone', true)
% 
% % ===== Control
% figure
% plot(tout, simout(3, :))
% xlabel('Tiempo (s)')
% ylabel('Acción de control (N)')
% matlab2tikz('../Fig/state_feed_con.tex', 'standalone', true)
