% Discrete

% Author: Sergio Andres Lenis Zapata
% Course: Linear Systems
% Date: Saturday, 18 November 2017

%% Discrete State-Space
% Clear variables and Clear command window
% clear
% clc

% Linear system
linmod_trfunc

% Sampling time
Ts = 0.03;

% Discrete
S_d = c2d(S, 0.03);

% Transfer function
Gc = tf(S_d);
Gczpk = zpk(tf(S_d));

%% Controllability
M_cc = ctrb(S);
M_cd = ctrb(S_d);