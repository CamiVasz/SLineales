% State Feedback

% Author: Sergio Andres Lenis Zapata
% Course: Linear Systems
% Date: Sunday, 19 November 2017

%% State Feedback
% Clear variables and Clear command window
clear
clc

% Initialise
% initvar
analog_filters
discrete_model

% Initial conditions
x_0 = 10;
theta_0 = pi / 4;

% Discrete S_d
%
K = acker(S_d.A, S_d.B, [0.95 0.95 0.95 0.95]);

%% Plot
t_f = 40;
len_v = linspace(0.3, 2.9, 5);

% Figure
figure
hold on
for i_len = 1 : length(len_v)
    len = len_v(i_len);
    simOut = sim('state_feedback_mod', 'StopTime', num2str(t_f), ...
        'SaveTime', 'on', 'TimeSaveName', 't', ...
        'ReturnWorkspaceOutputs', 'on');
    tout = simOut.get('t')';
    simout = simOut.get('simout')';
    
    % ===== Position
%     figure
%     plot(tout, simout(1, :))
%     xlabel('Tiempo (s)')
%     ylabel('Posición del carro (m)')
%     matlab2tikz('../Fig/state_feed_pos.tex', 'standalone', true)
    
    % ===== Angle
    plot(tout, simout(2, :))
    
    % ===== Control
%     figure
%     plot(tout, simout(3, :))
%     xlabel('Tiempo (s)')
%     ylabel('Acción de control (N)')
%     matlab2tikz('../Fig/state_feed_con.tex', 'standalone', true)
%     pause
%     close all
end
    legend('0.3000', '0.9500', '1.6000', '2.2500', '2.900')
    xlabel('Tiempo (s)')
    ylabel('Ángulo del péndulo (rad)')
    matlab2tikz('../Fig/state_feed_sens.tex', 'standalone', true)
