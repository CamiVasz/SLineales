% Analog Filters

% Author: Sergio Andres Lenis Zapata
% Course: Linear Systems
% Date: Saturday, 18 November 2017

%% Analog Filters
% Clear variables and Clear command window
% clear
% clc

% % Polynomial Multiplication
% p1 = [1 9 40];
% p2 = [1 4];
% Den = zeros(1, length(p1) + length(p2) - 1);
% 
% for i = 1 : length(p1)
%     for j = 1 : length(p2)
%         Den(i + j - 1) = Den(i + j - 1) + p1(i) * p2(j);
%     end
% end
% 
% % Transfer Function
% Num = [25 100];
% % Den = [ ... ];
% G = tf(Num, Den);

% Initialise
% linmod_trfunc

%% Filter
% Parameters
w_B = 7.35;

% Order 6
% Filter 1
w = 1.90;
zeta = 0.49;
[ G_f1 ] = analogfilter( w, zeta, w_B );

% Filter 2
w = 1.69;
zeta = 0.82;
[ G_f2 ] = analogfilter( w, zeta, w_B );

% Filter 2
w = 1.61;
zeta = 0.98;
[ G_f3 ] = analogfilter( w, zeta, w_B );

% Filter 3
G_f = G_f1 * G_f2 * G_f3;

Num_f = cell2mat(G_f.Numerator);
Den_f = cell2mat(G_f.Denominator);

%% Plot
% plot(tout, pend_ang(:, 1), tout, pend_ang(:, 2))
% title('Efecto del filtro en la salida')
% legend('Con filtro', 'Sin filtro')
% xlabel('Tiempo (s)')
% ylabel('Ángulo del péndulo (rad)')
% matlab2tikz('../Fig/filter_effect.tex', 'standalone', true)