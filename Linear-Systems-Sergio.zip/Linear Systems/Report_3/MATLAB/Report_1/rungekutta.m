function [ t_rk, x_rk ] = rungekutta( t_f, h, x0, f_1, f_2, f_3, f_4 )
% Runge–Kutta (RK4)
% Author: Sergio Andres Lenis Zapata
% Course: Linear Systems
% Date: Monday, 30 October 2017

% Time
t_rk = 0 : h : t_f;
t_i = 0;

% Index
i = 1;

% State variables
x_rk = zeros(4, length(t_rk));
x_rk(:, i) = x0;
i = i + 1;
t_i = t_i + h;

% Runge–Kutta
while t_i <= t_f
    % ========== Calculate auxiliary variables ==========
    % k = [k1 k2 k3 k4]
    % ===== K1_rk =====
    k(1, 1) = f_1(x_rk(:, i - 1));
    k(2, 1) = f_2(x_rk(:, i - 1));
    k(3, 1) = f_3(x_rk(:, i - 1));
    k(4, 1) = f_4(x_rk(:, i - 1));
    
    % ===== K2_rk =====
    k(1, 2) = f_1(x_rk(:, i - 1) + (h / 2) * k(:, 1));
    k(2, 2) = f_2(x_rk(:, i - 1) + (h / 2) * k(:, 1));
    k(3, 2) = f_3(x_rk(:, i - 1) + (h / 2) * k(:, 1));
    k(4, 2) = f_4(x_rk(:, i - 1) + (h / 2) * k(:, 1));
    
    % ===== K3_rk =====
    k(1, 3) = f_1(x_rk(:, i - 1) + (h / 2) * k(:, 2));
    k(2, 3) = f_2(x_rk(:, i - 1) + (h / 2) * k(:, 2));
    k(3, 3) = f_3(x_rk(:, i - 1) + (h / 2) * k(:, 2));
    k(4, 3) = f_4(x_rk(:, i - 1) + (h / 2) * k(:, 2));
    
    % ===== K4_rk =====
    k(1, 4) = f_1(x_rk(:, i - 1) + h * k(:, 3));
    k(2, 4) = f_2(x_rk(:, i - 1) + h * k(:, 3));
    k(3, 4) = f_3(x_rk(:, i - 1) + h * k(:, 3));
    k(4, 4) = f_4(x_rk(:, i - 1) + h * k(:, 3));
    
    % Update state variables
    x_rk(:, i) = x_rk(:, i - 1) + (h / 6) * ...
        (k(:, 1) + 2 * k(:, 2) + 2 * k(:, 3) + k(:, 4));
    
    % Update indices
    i = i + 1;
    t_i = t_i + h;
end
end