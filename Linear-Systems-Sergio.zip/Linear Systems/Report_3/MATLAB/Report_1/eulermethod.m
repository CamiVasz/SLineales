function [ t_e, x_e ] = eulermethod( t_f, h, x0, f_1, f_2, f_3, f_4 )
% Euler Method
% Author: Sergio Andres Lenis Zapata
% Course: Linear Systems
% Date: Monday, 30 October 2017

% Time
t_e = 0 : h : t_f;
t_i = 0;

% Index
i = 1;

% State variables
x_e = zeros(4, length(t_e));
x_e(:, i) = x0;
i = i + 1;
t_i = t_i + h;

% Euler Method
while t_i <= t_f
    % Update state variables
    x_e(1, i) = x_e(1, i - 1) + h * f_1(x_e(:, i - 1));
    x_e(2, i) = x_e(2, i - 1) + h * f_2(x_e(:, i - 1));
    x_e(3, i) = x_e(3, i - 1) + h * f_3(x_e(:, i - 1));
    x_e(4, i) = x_e(4, i - 1) + h * f_4(x_e(:, i - 1));
    
    % Update indices
    i = i + 1;
    t_i = t_i + h;
end
end