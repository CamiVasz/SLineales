% Numerical methods
% Inverted Pendulum

% Author: Sergio Andres Lenis Zapata
% Course: Linear Systems
% Date: Saturday, 18 November 2017

%% ===== Initialise =====
% Remove items from workspace, Remove specified figure and Clear Command Window
clear
close all
clc

% Initialise variables
initvar

% New initial conditions
theta_0 = pi / 4;
x0 = [x_0 theta_0 xdot_0 thetadot_0]';

% Input
u = 0;

% State equations
f_1 = @(x) x(3);
f_2 = @(x) x(4);
f_3 = @(x) ((inertia + mp * len^2) * ...
    (u - b * x(3) + mp * len * x(4)^2 * sin(x(2))) + ...
    mp^2 * g * len^2 * sin(x(2)) * cos(x(2))) / ...
    (inertia * (mc + mp) + mc * mp * len^2 + mp^2 * len^2 * sin(x(2))^2);
f_4 = @(x) (- mp * len * (u - b * x(3) + mp * len * x(4)^2 * sin(x(2))) - ...
    mp * g * len * (mc + mp) * sin(x(2))) / ...
    (inertia * (mc + mp) + mc * mp * len^2 + mp^2 * len^2 * sin(x(2))^2);

% Simulation time
t_f = 200;

%% ========== Simulink ==========
% Input
ind = 1;              % Index _ Constant
u_amp = 0;

% Simulink
simOut = sim('inverted_pendulum', 'StopTime', num2str(t_f), ...
    'SaveTime', 'on', 'TimeSaveName', 't', ...
    'ReturnWorkspaceOutputs', 'on');
t_sim = simOut.get('t')';
theta_sim = simOut.get('theta')';
x_sim = simOut.get('x')';

%% ========== Euler Method ==========
% Step size
h1 = 1 / 5000;

% Euler Method
[ t_e, x_e ] = eulermethod( t_f, h1, x0, f_1, f_2, f_3, f_4 );

% Resize vectors
num = 500;
t_e = t_e(1 : num : end);
x_e = x_e(:, 1 : num : end);

%% ========== Runge–Kutta (RK4) ==========
% Step size
h2 = 1 / 10;

% Runge–Kutta
[ t_rk, x_rk ] = rungekutta( t_f, h2, x0, f_1, f_2, f_3, f_4 );

%% ========== Plot ==========
% ===== Position
figure
plot(t_sim, x_sim, t_e, x_e(1, :), t_rk, x_rk(1, :))
legend('Simulink', 'Método de Euler', 'Runge–Kutta')
xlabel('Tiempo (s)')
ylabel('Posición del carro (m)')
% matlab2tikz('../Fig/num_methods_pos.tex', 'standalone', true)

% ===== Angle
figure
plot(t_sim, theta_sim, t_e, x_e(2, :), t_rk, x_rk(2, :))
legend('Simulink', 'Método de Euler', 'Runge–Kutta')
xlabel('Tiempo (s)')
ylabel('Ángulo del péndulo (rad)')
% matlab2tikz('../Fig/num_methods_ang.tex', 'standalone', true)