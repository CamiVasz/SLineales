% Change of parameters
% Inverted Pendulum

% Author: Sergio Andres Lenis Zapata
% Course: Linear Systems
% Date: Saturday, 18 November 2017

%% ========== Mass of the cart ==========
% Remove items from workspace, Remove specified figure and Clear Command Window
clear
close all
clc

% Initialise variables
initvar
theta_0 = pi / 4;   % Initial angle

% Simulation time
t_f = 200;

% Figure
figure(1)
hold on
figure(2)
hold on

% Simulink
for mc = [0.5 0.25 0.125]
    simOut = sim('inverted_pendulum', 'StopTime', num2str(t_f), ...
        'SaveTime', 'on', 'TimeSaveName', 't', ...
        'ReturnWorkspaceOutputs', 'on');
    t_sim = simOut.get('t')';
    theta_sim = simOut.get('theta')';
    x_sim = simOut.get('x')';
    
    % Plot
    figure(1)
    plot(t_sim, x_sim)
    figure(2)
    plot(t_sim, theta_sim)
end

% ===== Position
figure(1)
legend('M_p', 'M_1 < M_p', 'M_2 < M_1')
xlabel('Tiempo (s)')
ylabel('Posición del carro (m)')
% matlab2tikz('../Fig/chparam_mc_pos.tex', 'standalone', true)

% ===== Angle
figure(2)
legend('M_p', 'M_1 < M_p', 'M_2 < M_1')
xlabel('Tiempo (s)')
ylabel('Ángulo del péndulo (rad)')
% matlab2tikz('../Fig/chparam_mc_ang.tex', 'standalone', true)

% Pause
pause

%% ========== Length to the pendulum center of mass ==========
% Remove items from workspace, Remove specified figure and Clear Command Window
clear
close all
clc

% Initialise variables
initvar

% Input
ind = 1;              % Index _ Constant
u_amp = 0;

% Simulation time
t_f = 200;

% Figure
figure(1)
hold on
figure(2)
hold on

% Simulink
for len = [0.3 0.15 0.075]
    simOut = sim('inverted_pendulum', 'StopTime', num2str(t_f), ...
        'SaveTime', 'on', 'TimeSaveName', 't', ...
        'ReturnWorkspaceOutputs', 'on');
    t_sim = simOut.get('t')';
    theta_sim = simOut.get('theta')';
    x_sim = simOut.get('x')';
    
    % Plot
    figure(1)
    plot(t_sim, x_sim)
    figure(2)
    plot(t_sim, theta_sim)
end

% ===== Position
figure(1)
legend('l_p', 'l_1 < l_p', 'l_2 < l_1')
xlabel('Tiempo (s)')
ylabel('Posición del carro (m)')
% matlab2tikz('../Fig/chparam_len_pos.tex', 'standalone', true)

% ===== Angle
figure(2)
legend('l_p', 'l_1 < l_p', 'l_2 < l_1')
xlabel('Tiempo (s)')
ylabel('Ángulo del péndulo (rad)')
% matlab2tikz('../Fig/chparam_len_ang.tex', 'standalone', true)