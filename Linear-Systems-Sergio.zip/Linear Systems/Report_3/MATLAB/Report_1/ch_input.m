% Change inputs
% Inverted Pendulum

% Author: Sergio Andres Lenis Zapata
% Course: Linear Systems
% Date: Saturday, 18 November 2017

%% ========== Input ==========
% Remove items from workspace, Remove specified figure and Clear Command Window
clear
close all
clc

% Initialise variables
initvar

% Simulation time
t_f = 160;

% Legend
leg = {'Escalón', 'Función seno', 'Escalera'};
ylab = {'Posición del carro (m)', 'Ángulo del péndulo (rad)', 'Entrada (N)'};

% Input
% 2 - Step
% 3 - Sine Wave
% 4 - Stair Generator

% Input
i = 1;

% Index
ind = i + 1;

for j = 1 : 3
    % Figure
    figure(j)
    hold on
end

simOut = sim('inverted_pendulum', 'StopTime', num2str(t_f), ...
    'SaveTime', 'on', 'TimeSaveName', 't', ...
    'ReturnWorkspaceOutputs', 'on');
t = simOut.get('t')';
theta = simOut.get('theta')';
x = simOut.get('x')';
u = simOut.get('u')';
sim = [x; theta; u];

for j = 1 : 3
    figure(j)
    plot(t, sim(j, :))
    if j == 3
        legend(leg(i))
        axis([0 t_f -1.2 1.2])
    end
    xlabel('Tiempo (s)')
    ylabel(ylab(j))
    
    fname = '../Fig/ch_input';
    if j == 1
        fname = [fname, '_u', num2str(i), '_pos'];
    elseif j == 2
        fname = [fname, '_u', num2str(i), '_ang'];
    else
        fname = [fname, '_u', num2str(i), '_input'];
    end
%     fname = [fname, '.tex'];
%     matlab2tikz(fname, 'standalone', true)
end